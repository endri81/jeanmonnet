---
apply_url: '#'
bg_image: images/backgrounds/page-title.jpg
date: "2022-11-15T09:00:00+01:00"
description: Kick-off event presenting the Jean Monnet Module
draft: false
image: images/events/event-2.jpg
location: Polytechnic University of Tirana
title: "PUT in Jean Monnet Network Kick-off Event"
type: event
---

### About the Event

The kick-off event "PUT in Jean Monnet Network" was held in November 2022 with the participation of researchers, institutional representatives, students, and team members of the module. The event contributed to presenting the module to the participants and marking the official start of the Jean Monnet activities at the Polytechnic University of Tirana.
